using System.Collections;
using UnityEngine;

//este script gerencia a cria�ao de clones, levando em considera�ao as condi�oes e op�oes definidas no Editor. 
public class Clone_Skill : Skill
{
    [Header("Clone Info")]
    [SerializeField] private GameObject clonePrefab;
    [SerializeField] private float cloneDur;
    [Space]
    [SerializeField] private bool canAttack;
    [Space]

    [Header("Clone Duplicate")]
    [SerializeField] private float chanceToDuplicate;
    [SerializeField] private bool duplicateClone;

    [Header("Cystal instead of Clone")]
    public bool crystalInsteadOfClone;


    public void CreateClone(Transform _clonePosition, Vector3 _offset) //metodo para criar um clone na posi�ao especificada com um deslocamento
    {
        if (crystalInsteadOfClone) // verifica se a op�ao esta ativa. se sim chama o cristal em vez de criar um clone
        {
            SkillManager.instance.crystal.CreateCrystal();
            return;
        }

        GameObject newClone = Instantiate(clonePrefab); //instancia um novo clone a partir do prefab

        newClone.GetComponent<Clone_SkillController>(). //obtem o componente do controller e chama o seu metodo de setup para configurar o comportamento
            SetupClone(_clonePosition, cloneDur, canAttack, _offset, FindClosestEnemy(newClone.transform), duplicateClone, chanceToDuplicate, player);
    }

    public void CreateCloneWithDelay(Transform _enemyTransform)
    {
        StartCoroutine(CloneDelayCoroutine(_enemyTransform, new Vector3(2 * player.facingDir, 0)));
    }

    private IEnumerator CloneDelayCoroutine(Transform _transform, Vector3 _offset)
    {
        yield return new WaitForSeconds(.2f);
        CreateClone(_transform, _offset);
    }
}
