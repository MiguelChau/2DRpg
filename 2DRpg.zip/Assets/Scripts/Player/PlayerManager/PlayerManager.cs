using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Este script vai ser o nosso Singleton
public class PlayerManager : MonoBehaviour
{
    public static PlayerManager instance;
    public Player player;

    public int experience;

    private void Awake()
    {
        if (instance != null)
            Destroy(instance.gameObject);
        else
            instance = this;
    }

    public bool ExperienceEnough(int _exp)
    {
        if(_exp > experience)
        {
            Debug.Log("nout enough exp");
            return false;
        }

        experience = experience - _exp;
        return true;
    }
}
